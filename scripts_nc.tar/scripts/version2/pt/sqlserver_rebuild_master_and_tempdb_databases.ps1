﻿
Function ExecuteSQLScript($ScriptName,$LogFileName,$ScriptContent) {

    # Create SQL file and write new content or replace existing content in the file
    #
    Set-Content -Path "$($RebuildDatabaseParams.SQLTempDBDir)\$($ScriptName)" -Value $($ScriptContent) -Force

    Write-Host "`nExecuting $($RebuildDatabaseParams.SQLTempDBDir)\$($ScriptName) script with the following content:`n"
    Write-Host "$($ScriptContent)`n"

    Invoke-Sqlcmd -InputFile "$($RebuildDatabaseParams.SQLTempDBDir)\$($ScriptName)" -AbortOnError:$false -Verbose -Querytimeout 0 | Out-File -FilePath "$($RebuildDatabaseParams.SQLTempDBDir)\$($LogFileName)"

    Write-Host "Script executed.`nLogfile $($RebuildDatabaseParams.SQLTempDBDir)\$($LogFileName) "
}


# Read JSON config file
#
$RebuildDatabaseConfigFile = Split-Path $script:MyInvocation.MyCommand.Path
$RebuildDatabaseConfigFile += "\sqlserver_rebuild_master_and_tempdb_databases_parameters.json"
$RebuildDatabaseJsonObject = Get-Content $RebuildDatabaseConfigFile | ConvertFrom-Json

$RebuildDatabaseParams = $RebuildDatabaseJsonObject.database_parameters

$confirmpreference = 'none'

$SQLSysAdminAccountsList = "$($env:UserDomain)\$($env:UserName) $($RebuildDatabaseParams.SQLSysAdminAccounts -join ' ')"

$NumberOfTempFiles = (8, $((Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors)|Measure-Object -Minimum).Minimum

$RebuildInfoMessage = @"

Rebuiliding 'master' database with the following parameters:

    /QUIET 
    /ACTION=REBUILDDATABASE
    /INSTANCENAME=$($RebuildDatabaseParams.InstanceName)
    /SQLSYSADMINACCOUNTS=$($SQLSysAdminAccountsList)
    /SQLCOLLATION=$($RebuildDatabaseParams.SQLCollation)
    /SQLTEMPDBFILECOUNT=1
    /SQLTEMPDBFILESIZE=$($RebuildDatabaseParams.SQLTempDBFileSizeGB) [GB]
    /SQLTEMPDBFILEGROWTH=$($RebuildDatabaseParams.SQLTempDBFileGrowthGB) [GB]
    /SQLTEMPDBLOGFILESIZE=$($RebuildDatabaseParams.SQLTempDBLogFileSizeGB) [GB]
    /SQLTEMPDBLOGFILEGROWTH=$($RebuildDatabaseParams.SQLTempDBLogFileGrowthGB) [GB]
    /SQLTEMPDIR=$($RebuildDatabaseParams.SQLTempDBDir)
    /SQLTEMPDBLOGDIR=$($RebuildDatabaseParams.SQLTempDBLogDir)
    
"@

Write-Host $RebuildInfoMessage

# Rebuild the master database specifying the new collation in the SQLCOLLATION property of the setup command
Start-Process "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\SQL2017\setup.exe" -ArgumentList "/QUIET /ACTION=REBUILDDATABASE /INSTANCENAME=$($RebuildDatabaseParams.InstanceName) /SQLSYSADMINACCOUNTS=$($SQLSysAdminAccountsList) /SQLCOLLATION=$($RebuildDatabaseParams.SQLCollation) /SQLTEMPDBFILECOUNT=1" -Wait

Write-Host "`n'master' database rebuilt"

# Create TempDB directory, if not exists
#
New-Item $($RebuildDatabaseParams.SQLTempDBDir) -ItemType directory -Confirm:$false -Force | Out-Null

$PostRebuildSQLScript1 = @"
USE MASTER;
GO
ALTER DATABASE tempdb MODIFY FILE (NAME = tempdev, FILENAME= '$($RebuildDatabaseParams.SQLTempDBDir)\tempdb.mdf' );
GO
ALTER DATABASE tempdb MODIFY FILE (NAME = templog, filename = '$($RebuildDatabaseParams.SQLTempDBLogDir)\templog.ldf' );
GO
"@

ExecuteSQLScript "tempdb_modify1.sql" "tempdb_modify1.log" $PostRebuildSQLScript1

# Restart SQL services
#
Write-Host "`nRestarting SQL services ..."

Restart-Service -Name MSSQLSERVER -Force -Confirm:$false 
Restart-Service -Name SQLSERVERAGENT -Force -Confirm:$false 

Write-Host "Services restarted."

$PostRebuildSQLScript2 = @"
ALTER DATABASE [tempdb] MODIFY FILE (NAME = N'tempdev', SIZE = $($RebuildDatabaseParams.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($RebuildDatabaseParams.SQLTempDBFileGrowthGB)GB );
GO
ALTER DATABASE [tempdb] MODIFY FILE (NAME = N'templog', SIZE = $($RebuildDatabaseParams.SQLTempDBLogFileSizeGB)GB, FILEGROWTH = $($RebuildDatabaseParams.SQLTempDBLogFileGrowthGB)GB );
GO
$(
$nl = [Environment]::NewLine
$commands = ""
for ($fileNumber=2; $fileNumber -le $NumberOfTempFiles; $fileNumber++) {    
    $commands += "ALTER DATABASE [tempdb] ADD FILE (NAME = N'temp$($fileNumber)', FILENAME = '$($RebuildDatabaseParams.SQLTempDBDir)\tempdb$($fileNumber).mdf', SIZE = $($RebuildDatabaseParams.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($RebuildDatabaseParams.SQLTempDBFileGrowthGB)GB);$($nl)GO$($nl)"
    $commands += "ALTER DATABASE [tempdb] MODIFY FILE (NAME = N'temp$($fileNumber)', FILENAME = '$($RebuildDatabaseParams.SQLTempDBDir)\tempdb$($fileNumber).mdf' );$($nl)GO$($nl)"
    $commands += "ALTER DATABASE [tempdb] MODIFY FILE (NAME = N'temp$($fileNumber)', SIZE = $($RebuildDatabaseParams.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($RebuildDatabaseParams.SQLTempDBFileGrowthGB)GB);$($nl)GO$($nl)"    
    #$commands += "ALTER DATABASE [tempdb] ADD FILE (NAME = N'temp$($fileNumber)', FILENAME = '$($RebuildDatabaseParams.SQLTempDBDir)\tempdb$($fileNumber).mdf', SIZE = $($RebuildDatabaseParams.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($RebuildDatabaseParams.SQLTempDBFileGrowthGB)GB);$($nl)GO$($nl)"
}
$commands
)
"@

ExecuteSQLScript "tempdb_modify2.sql" "tempdb_modify2.log" $PostRebuildSQLScript2

# Restart SQL services
#
Write-Host "`nRestarting SQL services ..."

Restart-Service -Name MSSQLSERVER -Force -Confirm:$false 
Restart-Service -Name SQLSERVERAGENT -Force -Confirm:$false 

Write-Host "Services restarted."