﻿
# Read JSON config file
#
$RebuildDatabaseConfigFile = Split-Path $script:MyInvocation.MyCommand.Path
$RebuildDatabaseConfigFile += "\sqlserver_rebuild_master_and_tempdb_databases_parameters.json"
$RebuildDatabaseJsonObject = Get-Content $RebuildDatabaseConfigFile | ConvertFrom-Json

$RebuildDatabaseParams = $RebuildDatabaseJsonObject.database_parameters

$confirmpreference = 'none'

$SQLSysAdminAccountsList = "$($env:UserDomain)\$($env:UserName) $($RebuildDatabaseParams.SQLSysAdminAccounts -join ' ')"

$NumberOfTempFiles = (8, $((Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors)|Measure-Object -Minimum).Minimum

$RebuildInfoMessage = @"

Rebuiliding 'master' database with the following parameters:

    /QUIET 
    /ACTION=REBUILDDATABASE
    /INSTANCENAME=$($RebuildDatabaseParams.InstanceName)
    /SQLSYSADMINACCOUNTS=$($SQLSysAdminAccountsList)
    /SQLCOLLATION=$($RebuildDatabaseParams.SQLCollation)
    /SQLTEMPDBFILECOUNT=$($NumberOfTempFiles)
    /SQLTEMPDBFILESIZE=$($RebuildDatabaseParams.SQLTempDBFileSizeGB) [GB]
    /SQLTEMPDBFILEGROWTH=$($RebuildDatabaseParams.SQLTempDBFileGrowthGB) [GB]
    /SQLTEMPDBLOGFILESIZE=$($RebuildDatabaseParams.SQLTempDBLogFileSizeGB) [GB]
    /SQLTEMPDBLOGFILEGROWTH=$($RebuildDatabaseParams.SQLTempDBLogFileGrowthGB) [GB]
    /SQLTEMPDIR=$($RebuildDatabaseParams.SQLTempDBDir)
    /SQLTEMPDBLOGDIR=$($RebuildDatabaseParams.SQLTempDBLogDir)
"@

Write-Host $RebuildInfoMessage

# Rebuild the master database specifying the new collation in the SQLCOLLATION property of the setup command
Start-Process "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\SQL2017\setup.exe" -ArgumentList "/QUIET /ACTION=REBUILDDATABASE /INSTANCENAME=$($RebuildDatabaseParams.InstanceName) /SQLSYSADMINACCOUNTS=$($SQLSysAdminAccountsList) /SQLCOLLATION=$($RebuildDatabaseParams.SQLCollation)" -Wait

Write-Host "`n'master' database rebuilt"

$PostRebuildSQLScript = @"
USE MASTER;
GO
ALTER DATABASE tempdb MODIFY FILE (NAME = tempdev, FILENAME= '$($RebuildDatabaseParams.SQLTempDBDir)\tempdb.mdf', SIZE = $($RebuildDatabaseParams.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($RebuildDatabaseParams.SQLTempDBFileGrowthGB)GB );
GO
ALTER DATABASE tempdb MODIFY FILE (NAME = templog, filename = '$($RebuildDatabaseParams.SQLTempDBLogDir)\templog.ldf', SIZE = $($RebuildDatabaseParams.SQLTempDBLogFileSizeGB)GB, FILEGROWTH = $($RebuildDatabaseParams.SQLTempDBLogFileGrowthGB)GB );
GO
$(
$nl = [Environment]::NewLine
$commands = ""
for ($fileNumber=2; $fileNumber -le $NumberOfTempFiles; $fileNumber++) {    
    $commands += "ALTER DATABASE tempdb ADD FILE (NAME = temp$($fileNumber), FILENAME = '$($RebuildDatabaseParams.SQLTempDBDir)\tempdb$($fileNumber).mdf', SIZE = $($RebuildDatabaseParams.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($RebuildDatabaseParams.SQLTempDBFileGrowthGB)GB);$nl"
    $commands += "GO$nl"
}
$commands
)
"@

# $PostRebuildSQLScript

# Create TempDB directory, if not exists
#
New-Item $($RebuildDatabaseParams.SQLTempDBDir) -ItemType directory -Confirm:$false -Force | Out-Null

# Create SQL file and write new content or replace existing content in the file
#
$PostRebuildSQLScriptName = "tempdb_modify.sql"
$PostRebuildSQLScriptLogName = "tempdb_modify.log"

Set-Content -Path "$($RebuildDatabaseParams.SQLTempDBDir)\$($PostRebuildSQLScriptName)" -Value $($PostRebuildSQLScript) -Force

Write-Host "`nExecuting $($RebuildDatabaseParams.SQLTempDBDir)\$($PostRebuildSQLScriptName) script with the following content:`n"
Write-Host "$($PostRebuildSQLScript)`n"

Invoke-Sqlcmd -InputFile "$($RebuildDatabaseParams.SQLTempDBDir)\$($PostRebuildSQLScriptName)" -AbortOnError:$false -Verbose | Out-File -FilePath "$($RebuildDatabaseParams.SQLTempDBDir)\$($PostRebuildSQLScriptLogName)"

Write-Host "Script executed.`nLogfile $($RebuildDatabaseParams.SQLTempDBDir)\$($PostRebuildSQLScriptLogName) "

# Restart SQL services
#
Write-Host "`nRestarting SQL services ..."

Restart-Service -Name MSSQLSERVER -Force -Confirm:$false 
Restart-Service -Name SQLSERVERAGENT -Force -Confirm:$false 

Write-Host "Services restarted."