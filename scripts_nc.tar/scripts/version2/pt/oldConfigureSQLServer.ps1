<#
.Synopsis
   Sets the database owner to SA for all Databases in the Instance.
.DESCRIPTION
   This script will evaluate each database on the specified instance, and if the owner
   property is set to anything other than sa, it will change it to SA.
.EXAMPLE
   ./Set-DatabaseOwnerToSA.ps1 WS12SQL
.EXAMPLE
   ./Set-DatabaseOwnerToSA.ps1 WS12SQL\SQL01
#>

Write-Host "Hello World!"


Function ParseParameters() {

param (
    [string]$price = 100, 
    [string]$ComputerName = $env:computername,    
    [string]$username = $(throw "-username is required."),
    [string]$password = $( Read-Host -asSecureString "Input password" ),
    [switch]$SaveData = $false
)
write-output "The price is $price"
write-output "The Computer Name is $ComputerName"
write-output "The True/False switch argument is $SaveData"
 param (
    [string]$server = "http://defaultserver",
    [string]$password = $( Read-Host "Input password, please" ),
    [switch]$force = $false
 )
}




#ParseParameters

if ($force) {
  //deletes a file or does something "bad"
}
