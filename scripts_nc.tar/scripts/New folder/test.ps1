$hashdisks = @{}
$hashdisks.Add("LUN1", @{ "DriveLetter"="F"; "FileSystem"="NTFS"; "NewFileSystemLabel"="DBData" })
$hashdisks.Add("LUN2", @{ "DriveLetter"="L"; "FileSystem"="NTFS"; "NewFileSystemLabel"="DBLogs" })
$hashdisks.Add("LUN3", @{ "DriveLetter"="S"; "FileSystem"="NTFS"; "NewFileSystemLabel"="TransactionLogs" })

#$hashdisks
#$hashdisks.Keys

$physicaldisks = Get-PhysicalDisk
foreach ($physicaldisk in $physicaldisks) {
  $lun = "LUN" + ($physicaldisk.DeviceId - 1)

  if ($physicaldisk.FriendlyName -eq "Msft Virtual Disk" -and $hashdisks.ContainsKey($lun)) {
    
    Write-host "Initializing disk $lun - Drive:", $hashdisks[$lun].DriveLetter, "; Label:", $hashdisks[$lun].NewFileSystemLabel

    #Get-Disk | 
    #Where {$_.partitionstyle -eq 'raw' -and $_.UniqueId -eq $physicaldisk.UniqueId} |
    #Initialize-Disk -PartitionStyle MBR -PassThru |
    #New-Partition -DriveLetter $hashdisks[$lun].DriveLetter -UseMaximumSize |
    #Format-Volume -FileSystem $hashdisks[$lun].FileSystem -NewFileSystemLabel $hashdisks[$lun].NewFileSystemLabel -Confirm:$false
  }
}