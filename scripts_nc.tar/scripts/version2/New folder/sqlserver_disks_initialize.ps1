
# Read JSON config file
#
$DiskLayoutConfigFile = Split-Path $script:MyInvocation.MyCommand.Path
$DiskLayoutConfigFile += "\sqlserver_disks_layout.json"
$DiskLayoutJsonObject = Get-Content $DiskLayoutConfigFile | ConvertFrom-Json

$data_disks = $DiskLayoutJsonObject.data_disks

#$DiskLayoutJsonObject.psobject.properties.name

# prevent confirmation pop-ups
#
$confirmpreference = 'none'

$physicalDisks = Get-PhysicalDisk

# Iterate over physical disks to initialize them and create directory structure
#
foreach ($physicalDisk in ($physicalDisks| Sort-Object -Property DeviceId) ) {

  # Local variables
  #
  $lun = "LUN" + ($physicalDisk.DeviceId - 1)
  $deviceId = $physicalDisk.DeviceId

  #if ($physicalDisk.FriendlyName -eq "Msft Virtual Disk" -and $DiskLayoutJsonObject.psobject.Properties.name -contains $lun) {
  if ($physicalDisk.FriendlyName -eq "Msft Virtual Disk" -and $data_disks.psobject.Properties.name -match $deviceId) {  
    
    Write-host

    # Initialize disks
    #    
    Write-host "Initializing disk $lun - [Drive: ", $data_disks.$deviceId.DriveLetter, ", Label: ", $data_disks.$deviceId.NewFileSystemLabel, "]. Please wait..." -Separator ""

    Get-Disk | 
      Where {$_.partitionstyle -eq 'raw' -and $_.UniqueId -eq $physicaldisk.UniqueId} |
      Initialize-Disk -PartitionStyle MBR -PassThru |
      New-Partition -DriveLetter $data_disks.$deviceId.DriveLetter -UseMaximumSize |
      Format-Volume -FileSystem $data_disks.$deviceId.FileSystem -NewFileSystemLabel $data_disks.$deviceId.NewFileSystemLabel -Confirm:$false

    # create directory structure
    #
    foreach ($directoryItem in $data_disks.$deviceId.Directories) {

      $newItemPath = $data_disks.$deviceId.DriveLetter + ":\" + $directoryItem
      Write-host "Creating directory ", $newItemPath -Separator ""
      
      New-Item $newItemPath -ItemType directory -Confirm:$false -Force | Out-Null
    }
  }
}

Write-host

# create other directories structure
#
foreach ($directoryItem in $DiskLayoutJsonObject.other_Directories) {

  Write-host "Creating directory ", $directoryItem -Separator ""
      
  New-Item $directoryItem -ItemType directory -Confirm:$false -Force | Out-Null
}