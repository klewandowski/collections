
$DiskLayoutConfigFile = Split-Path $script:MyInvocation.MyCommand.Path
$DiskLayoutConfigFile += "\sqlserver_disks_layout.json"
$DiskLayoutJsonObject = Get-Content $DiskLayoutConfigFile | ConvertFrom-Json

#$DiskLayoutJsonObject.psobject.properties.name

$physicalDisks = Get-PhysicalDisk
foreach ($physicalDisk in $physicalDisks) {
  $lun = "LUN" + ($physicalDisk.DeviceId - 1)

  if ($physicalDisk.FriendlyName -eq "Msft Virtual Disk" -and $DiskLayoutJsonObject.psobject.Properties.name -contains $lun) {
    
    Write-host "Initializing disk $lun - ( Drive:", $DiskLayoutJsonObject.$lun.DriveLetter, ", Label:", $DiskLayoutJsonObject.$lun.NewFileSystemLabel, "). Please wait..."

    Get-Disk | 
      Where {$_.partitionstyle -eq 'raw' -and $_.UniqueId -eq $physicaldisk.UniqueId} |
      Initialize-Disk -PartitionStyle MBR -PassThru |
      New-Partition -DriveLetter $DiskLayoutJsonObject.$lun.DriveLetter -UseMaximumSize |
      Format-Volume -FileSystem $DiskLayoutJsonObject.$lun.FileSystem -NewFileSystemLabel $DiskLayoutJsonObject.$lun.NewFileSystemLabel -Confirm:$false
  }
}