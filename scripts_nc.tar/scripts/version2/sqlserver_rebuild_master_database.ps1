﻿
# Read JSON config file
#
$RebuildMasterDatabaseConfigFile = Split-Path $script:MyInvocation.MyCommand.Path
$RebuildMasterDatabaseConfigFile += "\sqlserver_rebuild_master_database_parameters.json"
$RebuildMasterDatabaseJsonObject = Get-Content $RebuildMasterDatabaseConfigFile | ConvertFrom-Json

$RebuildMasterDatabaseParams = $RebuildMasterDatabaseJsonObject.master_database_parameters

$confirmpreference = 'none'

$SQLSysAdminAccountsList = "$($env:UserDomain)\$($env:UserName) $($RebuildMasterDatabaseParams.SQLSysAdminAccounts -join ' ')"

$HereString = @"

Rebuiliding 'master' database with the following parameters:
    /QUIET 
    /ACTION=REBUILDDATABASE
    /INSTANCENAME=$($RebuildMasterDatabaseParams.InstanceName)
    /SQLSYSADMINACCOUNTS=$($SQLSysAdminAccountsList)
    /SQLCOLLATION=$($RebuildMasterDatabaseParams.SQLCollation)
    /SQLTEMPDBFILECOUNT=$($RebuildMasterDatabaseParams.SQLTempDBFileCount)
    /SQLTEMPDBFILESIZE=$($RebuildMasterDatabaseParams.SQLTempDBFileSizeGB) [GB]
    /SQLTEMPDBFILEGROWTH=$($RebuildMasterDatabaseParams.SQLTempDBFileGrowthGB) [GB]
    /SQLTEMPDBLOGFILESIZE=$($RebuildMasterDatabaseParams.SQLTempDBLogFileSizeGB) [GB]
    /SQLTEMPDBLOGFILEGROWTH=$($RebuildMasterDatabaseParams.SQLTempDBLogFileGrowthGB) [GB]
    /SQLTEMPDIR=$($RebuildMasterDatabaseParams.SQLTempDBDir)
    /SQLTEMPDBLOGDIR=$($RebuildMasterDatabaseParams.SQLTempDBLogDir)
"@

Write-Host $HereString

# Rebuild the master database specifying the new collation in the SQLCOLLATION property of the setup command
#Start-Process "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\SQL2017\setup.exe" -ArgumentList "/QUIET /ACTION=REBUILDDATABASE /INSTANCENAME=$($RebuildMasterDatabaseParams.InstanceName) /SQLSYSADMINACCOUNTS=$($SQLSysAdminAccountsList) /SQLCOLLATION=$($RebuildMasterDatabaseParams.SQLCollation)" -Wait

