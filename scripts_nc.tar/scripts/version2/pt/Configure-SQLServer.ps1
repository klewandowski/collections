<#

.SYNOPSIS
This is a Powershell script to automate SQL Server configuration

.DESCRIPTION
The script itself will execute many steps required to configure database server and MS SQL database engine to end up with fully operational setup.

There are certain activities performed, including, but not limited to:
* [-ConfigFilePath]             : reading a config file
* [-InitializeDisks]            : initializing data disks, i.e. creating partitions and filesystems, assigning disk labels and drive letters
* [-CreateMandatoryDirectories] : creating a group of mandatory directories
* [-ConfigureSPNs]              : modifying Service Principal Names (SPN) directory property for Active Directory service accounts
* [-ConfigureServices]          : configuring MS SQL Services, i.e. Startup Type, Log On As (username and password)
* [-RebuildMasterDatabase]      : rebuilding 'master' database with selected parameters, such as collation, tempDB files, etc.
* [-AddFilesToTempDB]           : adding and resizing files to TempDB

.PARAMETER ConfigFilePath
Specifies the path to the JSON-based config file.
The path is either absolute or relative to the script folder.
Default: Configure-SQLServer.json  (in the script directory)

.PARAMETER InitializeDisks
Initialize data disks, i.e. create partitions, filesystems, assign disk labels and drive letters
Default: $true

.PARAMETER CreateMandatoryDirectories
Create directories specified in "MandatoryDirectories" list contained in the JSON config file.
Default: $true

.PARAMETER ConfigureSPNs
Modify the Service Principal Names (SPN) directory property for Active Directory service accounts to authenticate correctly.
SPNs are used to locate a target principal name for running a service.
Default: $true

.PARAMETER ConfigureServices
Configure MS SQL Services, i.e. Startup Type, Log On As (username and password)
Default: $true

.PARAMETER RebuildMasterDatabase
Rebuild 'master' database with parameters specified in the JSON config file.
This includes collation and tempDB files attributes (files location, count, size, growth).
Default: $true

.PARAMETER AddFilesToTempDB
Add files to 'tempdb'.
Default: $true

.PARAMETER RunAsAdmin
This script should be run from an elevated command prompt (Run as administrator) because it executes commands that require admin privileges.
However, you can disable this pre-check and run the script as a regular user. Expect errors in this case.
Default: $true

.PARAMETER Verbose
Displays detailed information about the operation done by the command. 
This information resembles the information in a trace. 
Default: $false

.PARAMETER WhatIf
This parameter allows you to see what the script would have done if it were to have run.
PowerShell will display the objects to be changed and the changes made. At the same time, no changes are actually made.
Default: $false

.PARAMETER Confirm
Prompts you for confirmation before executing the command.
Default: $false

.EXAMPLE

PS> .\Configure-SQLServer.ps1 -Verbose
(...)
VERBOSE: [ReadConfigFile]: Reading Configure-SQLServer.json config file ..
VERBOSE: [ReadConfigFile]: Reading Configure-SQLServer.json config file .. [Done]
(...)

.EXAMPLE

PS> .\Configure-SQLServer.ps1 -WhatIf
(...)
INFO: [CreateMandatoryDirectories]: Creating directory "D:\SQLServerTempDB" ..
What if: Performing the operation "Create Directory" on target "Destination: D:\SQLServerTempDB".
(...)

.NOTES
-Verbose
-Debug
-Full
-Example
-Detail
-WhatIf

Convert plain password to secure strings and then into encrypted standard strings - to save it into JSON config file.
"P@ssword1" | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString
The result is an encrypted standard string that you can then save for later retrieval.

.LINK
https://dev.azure.com/NCDBRE/Database%20Reliability%20Engineering

#>

#using namespace System.Management.Automation

[CmdletBinding(ConfirmImpact='Medium',
               DefaultParameterSetName = 'DefParamSet',
               SupportsPaging=$false,
               SupportsShouldProcess=$true,
               PositionalBinding=$false
)]
param (
    [Parameter(ParameterSetName='DefParamSet')][ValidateNotNullOrEmpty()][string]$ConfigFilePath = "Configure-SQLServer.json",
    [Parameter(ParameterSetName='DefParamSet')][switch]$InitializeDisks = $true,
    [Parameter(ParameterSetName='DefParamSet')][switch]$CreateMandatoryDirectories = $true,
    [Parameter(ParameterSetName='DefParamSet')][switch]$ConfigureSPNs = $true,
    [Parameter(ParameterSetName='DefParamSet')][switch]$ConfigureServices = $true,
    [Parameter(ParameterSetName='DefParamSet')][switch]$RebuildMasterDatabase = $true,
    [Parameter(ParameterSetName='DefParamSet')][switch]$AddFilesToTempDB = $true,
    [Parameter(ParameterSetName='DefParamSet')][switch]$RunAsAdmin = $true
)

    #[string]$price = 100, 
    #[Parameter(Mandatory=$true)][string]$ComputerName = $env:computername,    
    #[string]$username = $(throw "-username is required."),
    #[string]$password = $( Read-Host -asSecureString "Input password" ),


Function ReadConfigFile {

    if (!(Split-Path -Path $ConfigFilePath -IsAbsolute)) {
        $ConfigFilePath = "$(Split-Path -parent $PSCommandPath)\$($ConfigFilePath)"
    }

    Write-Debug "[$($MyInvocation.MyCommand)]: ConfigFile name: $($ConfigFilePath)"

    if (!(Test-Path $ConfigFilePath -PathType leaf)) {
        #Throw (New-Object System.IO.FileNotFoundException("File not found: $ConfigFilePath", $ConfigFilePath))
        Throw "[$($MyInvocation.MyCommand)]: File not found: $ConfigFilePath"
    }

    # Read JSON config file
    #
    Write-Verbose "[$($MyInvocation.MyCommand)]: Reading $($ConfigFilePath) config file .."
    $global:ConfigJsonObject = Get-Content $ConfigFilePath | ConvertFrom-Json
    Write-Verbose "[$($MyInvocation.MyCommand)]: Reading $($ConfigFilePath) config file .. [Done]"

    $global:ConfigDataDisks = $ConfigJsonObject.DataDisks
    $global:ConfigMandatoryDirectories = $ConfigJsonObject.MandatoryDirectories
    $global:ConfigServices = $ConfigJsonObject.Services
    $global:ConfigDatabaseParameters = $ConfigJsonObject.DatabaseParameters
}


Function InitializeDisks {

    # #Write-Progress -Activity "Creating directory" -Status 'Progress ->' -PercentComplete $I -CurrentOperation $directoryItem        
    Write-Verbose "[$($MyInvocation.MyCommand)]: Getting physical disks information .."
    $physicalDisks = Get-PhysicalDisk
    Write-Verbose "[$($MyInvocation.MyCommand)]: Getting physical disks information .. [Done]"

    # Iterate over physical disks to initialize them and create directory structure
    #
    foreach ($physicalDisk in ($physicalDisks| Sort-Object -Property DeviceId) ) {

        $lun = "LUN" + ($physicalDisk.DeviceId - 1)
        $deviceId = $physicalDisk.DeviceId
        Write-Debug "[$($MyInvocation.MyCommand)]: lun: $($lun), deviceId: $($deviceId)"

        if ($physicalDisk.FriendlyName -eq "Msft Virtual Disk" -and $ConfigDataDisks.psobject.Properties.name -match $deviceId) {  
           
            Write-Information "INFO: [$($MyInvocation.MyCommand)]:"
            # Initialize disks
            #    
            Write-Information "INFO: [$($MyInvocation.MyCommand)]: Initializing disk $($lun) - [Drive: $($ConfigDataDisks.$deviceId.DriveLetter), Label: $($ConfigDataDisks.$deviceId.NewFileSystemLabel)]. Please wait .."            

            Get-Disk | 
                Where-Object {$_.partitionstyle -eq 'raw' -and $_.UniqueId -eq $physicaldisk.UniqueId} |
                Initialize-Disk -PartitionStyle MBR -PassThru |
                New-Partition -DriveLetter $ConfigDataDisks.$deviceId.DriveLetter -UseMaximumSize |
                Format-Volume -FileSystem $ConfigDataDisks.$deviceId.FileSystem -NewFileSystemLabel $ConfigDataDisks.$deviceId.NewFileSystemLabel -Confirm:$false

            Write-Information "INFO: [$($MyInvocation.MyCommand)]: Disk $($lun) [Drive: $($ConfigDataDisks.$deviceId.DriveLetter), Label: $($ConfigDataDisks.$deviceId.NewFileSystemLabel)] initialized."

            # create directory structure
            #
            foreach ($directoryItem in $ConfigDataDisks.$deviceId.Directories) {
                $newItemPath = $ConfigDataDisks.$deviceId.DriveLetter + ":\" + $directoryItem            

                Write-Information "INFO: [$($MyInvocation.MyCommand)]: Creating directory `"$($newItemPath)`" .."                 
                New-Item $newItemPath -ItemType directory -Confirm:$false -Force | Out-Null
            }
        }
    }

}


Function CreateMandatoryDirectories {
    # create other directories structure
    #    
    foreach ($directoryItem in $ConfigMandatoryDirectories) {
                     
        Write-Information "INFO: [$($MyInvocation.MyCommand)]: Creating directory `"$($directoryItem)`" .." 
        #Write-InformationColored "INFO: [$($MyInvocation.MyCommand)]: Creating directory `"$($directoryItem)`" .." -ForegroundColor Green

        New-Item $directoryItem -ItemType directory -Confirm:$false -Force | Out-Null
     }
}


#Function ChangeService($sServiceName,$sComputerName,$sUsername,[SecureString] $sPassword,$sStartupType) {
Function ChangeService {    
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$sServiceName,
        [Parameter(Mandatory)][string]$sComputerName,
        [Parameter(Mandatory)][string]$sUsername,
        [Parameter(Mandatory)][SecureString]$sPassword,
        [Parameter(Mandatory)][string]$sStartupType
    )

    $oService = Get-WmiObject -ComputerName $sComputerName -Query "SELECT * FROM Win32_Service WHERE Name = '$sServiceName'"
    
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($sPassword)
    $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    # Powershell 7
    # $UnsecurePassword = ConvertFrom-SecureString -SecureString $sPassword -AsPlainText

    Write-Verbose "[$($MyInvocation.MyCommand)]: Setting $($sServiceName) service user to $($sUsername) .."
    $oService.Change($null,$null,$null,$null,$null,$null,$sUsername,$UnsecurePassword) | Out-Null
    Write-Verbose "[$($MyInvocation.MyCommand)]: Setting $($sServiceName) service user to $($sUsername) .. [done]"
    #Stop-Service -Name $sServiceName -Force -Confirm:$false
    #Start-Service -Name $sServiceName -Confirm:$false

    Write-Verbose "[$($MyInvocation.MyCommand)]: Setting $($sServiceName) service startup type to $($sStartupType) .."
    Set-Service -Name $sServiceName -StartupType $sStartupType | Out-Null
    Write-Verbose "[$($MyInvocation.MyCommand)]: Setting $($sServiceName) service startup type to $($sStartupType) .. [done]"

    Write-Verbose "[$($MyInvocation.MyCommand)]: Restarting $($sServiceName) service .."
    Restart-Service -Name $sServiceName -Force -Confirm:$false | Out-Null 
    Write-Verbose "[$($MyInvocation.MyCommand)]: Restarting $($sServiceName) service .. [done]"
}


Function ConfigureSPNs {

    if ( !(Test-Administrator) ) {
        Throw "ERROR: To use setspn, you must run the setspn command from an elevated command prompt."
        #Write-Error "ERROR: [$($MyInvocation.MyCommand)]: To use setspn, you must run the setspn command from an elevated command prompt."
        #return
    }

    $myFQDN = [System.Net.Dns]::GetHostByName($env:computerName).HostName

    foreach ($ServiceItem in $ConfigServices) {

        if ($ServiceItem.modifySPN -eq $true) {
            Write-Information "INFO: [$($MyInvocation.MyCommand)]:"

            # Modify a service Service Principal Names (SPN) information to authenticate correctly.
            #
            Write-Information "INFO: [$($MyInvocation.MyCommand)]: Modifying service account $($ServiceItem.Username) SPN information for $($ServiceItem.ServiceName) service .."            
            setspn -D MSSQLSvc/$($myFQDN):1433 $env:computername | Out-Null
            setspn -D MSSQLSvc/$($myFQDN) $env:computername | Out-Null
            setspn -S MSSQLSvc/$($myFQDN):1433 $($ServiceItem.Username) | Out-Null
            setspn -S MSSQLSvc/$($myFQDN) $($ServiceItem.Username) | Out-Null
            setspn -L $($ServiceItem.Username)            
            Write-Information "INFO: [$($MyInvocation.MyCommand)]: SPN updated"
        }
    }
}


Function ConfigureServices {

    foreach ($ServiceItem in $ConfigServices) {

        Write-Information "INFO: [$($MyInvocation.MyCommand)]:"

        # Change service settings
        #
        $SecurePassword = $ServiceItem.PasswordInEncryptedStandardString | ConvertTo-SecureString
        #$cred = New-Object -typename System.Management.Automation.PSCredential -argumentlist $ServiceItem.Username, $SecurePassword
        Write-Information "INFO: [$($MyInvocation.MyCommand)]: Changing $($ServiceItem.ServiceName) service settings .."
        ChangeService $ServiceItem.ServiceName $env:computername $ServiceItem.Username $SecurePassword $ServiceItem.StartupType
        Write-Information "INFO: [$($MyInvocation.MyCommand)]: $($ServiceItem.ServiceName) service restarted with updated settings."        
    }
}


Function ExecuteSQLScript {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ScriptPath,
        [Parameter(Mandatory)][string]$ScriptContent
    )
    # Create SQL file and write new content or replace existing content in the file
    #
    Write-Verbose "[$($MyInvocation.MyCommand)]: Preparing $($ScriptPath) SQL script .."
    Set-Content -Path $ScriptPath -Value "$($ScriptContent)" -Force
    Write-Verbose "[$($MyInvocation.MyCommand)]: Preparing $($ScriptPath) SQL script .. [done]"
    Write-Verbose "[$($MyInvocation.MyCommand)]: $($ScriptPath) script content:$($nl)$($ScriptContent)$($nl)"

    Write-Information "INFO: [$($MyInvocation.MyCommand)]: Executing $($ScriptPath) SQL script .."
    Invoke-Sqlcmd -InputFile $ScriptPath -AbortOnError:$false -Verbose -Querytimeout 0 | Out-Null
    Write-Information "INFO: [$($MyInvocation.MyCommand)]: Executing $($ScriptPath) SQL script .. [done]"
}


Function RebuildMasterDatabase {

    $SQLSysAdminAccountsList = "`"$($env:UserDomain)\$($env:UserName)`" $($ConfigDatabaseParameters.SQLSysAdminAccounts -join ' ')"

    @"
[$($MyInvocation.MyCommand)]: Rebuiliding 'master' database with the following parameters:

    /QUIET 
    /ACTION=REBUILDDATABASE
    /INSTANCENAME=$($ConfigDatabaseParameters.InstanceName)
    /SQLSYSADMINACCOUNTS=$($SQLSysAdminAccountsList)
    /SQLCOLLATION=$($ConfigDatabaseParameters.SQLCollation)
    /SQLTEMPDBFILECOUNT=1
    /SQLTEMPDBFILESIZE=$($ConfigDatabaseParameters.SQLTempDBFileSizeGB) [GB]
    /SQLTEMPDBFILEGROWTH=$($ConfigDatabaseParameters.SQLTempDBFileGrowthGB) [GB]
    /SQLTEMPDBLOGFILESIZE=$($ConfigDatabaseParameters.SQLTempDBLogFileSizeGB) [GB]
    /SQLTEMPDBLOGFILEGROWTH=$($ConfigDatabaseParameters.SQLTempDBLogFileGrowthGB) [GB]
    /SQLTEMPDIR=$($ConfigDatabaseParameters.SQLTempDBDir)
    /SQLTEMPDBLOGDIR=$($ConfigDatabaseParameters.SQLTempDBLogDir)

"@ | Write-Verbose
    
    # Rebuild the master database specifying the new collation and TempDB parameters
    #
    Write-Information "INFO: [$($MyInvocation.MyCommand)]: Rebuiliding 'master' database .."
    Start-Process "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\SQL2017\setup.exe" -ArgumentList "/QUIET /ACTION=REBUILDDATABASE /INSTANCENAME=$($ConfigDatabaseParameters.InstanceName) /SQLSYSADMINACCOUNTS=$($SQLSysAdminAccountsList) /SQLCOLLATION=$($ConfigDatabaseParameters.SQLCollation) /SQLTEMPDBFILECOUNT=1" -Wait
    Write-Information "INFO: [$($MyInvocation.MyCommand)]: Rebuiliding 'master' database .. [done]"

    # Create TempDB directory, if not exists
    #
    Write-Verbose "[$($MyInvocation.MyCommand)]: Creating $($ConfigDatabaseParameters.SQLTempDBDir) directory .."
    New-Item $($ConfigDatabaseParameters.SQLTempDBDir) -ItemType directory -Confirm:$false -Force | Out-Null
    Write-Verbose "[$($MyInvocation.MyCommand)]: Creating $($ConfigDatabaseParameters.SQLTempDBDir) directory .. [done]"

    $SQLScript = @"
USE MASTER;
GO
ALTER DATABASE tempdb MODIFY FILE (NAME = tempdev, FILENAME= '$($ConfigDatabaseParameters.SQLTempDBDir)\tempdb.mdf' );
GO
ALTER DATABASE tempdb MODIFY FILE (NAME = templog, filename = '$($ConfigDatabaseParameters.SQLTempDBLogDir)\templog.ldf' );
GO
"@
    ExecuteSQLScript "$($ConfigDatabaseParameters.SQLTempDBDir)\tempdb_modify1.sql" $SQLScript

    # Restart SQL services
    #
    Write-Information "INFO: [$($MyInvocation.MyCommand)]: Restarting SQL services .."
    foreach ($ServiceItem in $ConfigServices) {
        Write-Verbose "[$($MyInvocation.MyCommand)]: Restarting $($ServiceItem.ServiceName) service .."
        Restart-Service -Name $sServiceName -Force -Confirm:$false | Out-Null 
        Write-Verbose "[$($MyInvocation.MyCommand)]: Restarting $($ServiceItem.ServiceName) service .. [done]"
    }
    Write-Information "INFO: [$($MyInvocation.MyCommand)]: Restarting SQL services .. [done]"
}


Function AddFilesToTempDB {

    $NumberOfTempFiles = (8, $((Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors)|Measure-Object -Minimum).Minimum

    $SQLScript = @"
ALTER DATABASE [tempdb] MODIFY FILE (NAME = N'tempdev', SIZE = $($ConfigDatabaseParameters.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($ConfigDatabaseParameters.SQLTempDBFileGrowthGB)GB );
GO
ALTER DATABASE [tempdb] MODIFY FILE (NAME = N'templog', SIZE = $($ConfigDatabaseParameters.SQLTempDBLogFileSizeGB)GB, FILEGROWTH = $($ConfigDatabaseParameters.SQLTempDBLogFileGrowthGB)GB );
GO
$(
$nl = [Environment]::NewLine
$commands = ""
for ($fileNumber=2; $fileNumber -le $NumberOfTempFiles; $fileNumber++) {    
    $commands += "ALTER DATABASE [tempdb] ADD FILE (NAME = N'temp$($fileNumber)', FILENAME = '$($ConfigDatabaseParameters.SQLTempDBDir)\tempdb$($fileNumber).mdf', SIZE = $($ConfigDatabaseParameters.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($ConfigDatabaseParameters.SQLTempDBFileGrowthGB)GB);$($nl)GO$($nl)"
    $commands += "ALTER DATABASE [tempdb] MODIFY FILE (NAME = N'temp$($fileNumber)', FILENAME = '$($ConfigDatabaseParameters.SQLTempDBDir)\tempdb$($fileNumber).mdf' );$($nl)GO$($nl)"
    $commands += "ALTER DATABASE [tempdb] MODIFY FILE (NAME = N'temp$($fileNumber)', SIZE = $($ConfigDatabaseParameters.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($ConfigDatabaseParameters.SQLTempDBFileGrowthGB)GB);$($nl)GO$($nl)"    
    #$commands += "ALTER DATABASE [tempdb] ADD FILE (NAME = N'temp$($fileNumber)', FILENAME = '$($ConfigDatabaseParameters.SQLTempDBDir)\tempdb$($fileNumber).mdf', SIZE = $($ConfigDatabaseParameters.SQLTempDBFileSizeGB)GB, FILEGROWTH = $($ConfigDatabaseParameters.SQLTempDBFileGrowthGB)GB);$($nl)GO$($nl)"
}
$commands
)
"@
    ExecuteSQLScript "$($ConfigDatabaseParameters.SQLTempDBDir)\tempdb_modify2.sql" $SQLScript

    # Restart SQL services
    #
    Write-Information "INFO: [$($MyInvocation.MyCommand)]: Restarting SQL services .."
    foreach ($ServiceItem in $ConfigServices) {
        Write-Verbose "[$($MyInvocation.MyCommand)]: Restarting $($ServiceItem.ServiceName) service .."
        Restart-Service -Name $sServiceName -Force -Confirm:$false | Out-Null 
        Write-Verbose "[$($MyInvocation.MyCommand)]: Restarting $($ServiceItem.ServiceName) service .. [done]"
    }
    Write-Information "INFO: [$($MyInvocation.MyCommand)]: Restarting SQL services .. [done]"
}


Function Write-InformationColored {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [Object]$MessageData,
        [ConsoleColor]$ForegroundColor = $Host.UI.RawUI.ForegroundColor, # Make sure we use the current colours by default
        [ConsoleColor]$BackgroundColor = $Host.UI.RawUI.BackgroundColor,
        [Switch]$NoNewline
    )

    $msg = [HostInformationMessage]@{
        Message         = $MessageData
        ForegroundColor = $ForegroundColor
        BackgroundColor = $BackgroundColor
        NoNewline       = $NoNewline.IsPresent
    }

    Write-Information $msg
}


Function Test-Administrator  
{  
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}


############################
# Main
############################

# Global variables
#
Set-Variable -Name ConfigJsonObject -Scope global
Set-Variable -Name ConfigDataDisks -Scope global
Set-Variable -Name ConfigMandatoryDirectories -Scope global
Set-Variable -Name ConfigServices -Scope global
Set-Variable -Name ConfigDatabaseParameters -Scope global
Set-Variable -Name nl -Value [Environment]::NewLine -Scope global 

# prevent confirmation pop-ups
#
$ConfirmPreference = 'None'

# Other preferences
#
$WarningPreference = 'Continue'
$InformationPreference = 'Continue'

if ( !(Test-Administrator) -And $RunAsAdmin) {
    Throw "ERROR: You must run this script from an elevated command prompt."
}

ReadConfigFile
# if ($InitializeDisks) { InitializeDisks }
# if ($CreateMandatoryDirectories) { CreateMandatoryDirectories }
# if ($ConfigureSPNs) { ConfigureSPNs }
# if ($ConfigureServices) { ConfigureServices }
# if ($RebuildMasterDatabase) { RebuildMasterDatabase }
# if ($AddFilesToTempDB) { AddFilesToTempDB }
