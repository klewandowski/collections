﻿Function ChangeServiceAccount($sServiceName,$sComputerName,$sUsername,$sPassword) {

	$oService = Get-WmiObject -ComputerName $sComputerName -Query "SELECT * FROM Win32_Service WHERE Name = '$sServiceName'"
	$oService.Change($null,$null,$null,$null,$null,$null,$sUsername,$sPassword) | Out-Null
    #Stop-Service -Name $sServiceName -Force -Confirm:$false
    #Start-Service -Name $sServiceName -Confirm:$false
    Restart-Service -Name $sServiceName -Force -Confirm:$false   
}


# Read JSON config file
#
$ServiceAccountsConfigFile = Split-Path $script:MyInvocation.MyCommand.Path
$ServiceAccountsConfigFile += "\sqlserver_service_accounts.json"
$ServiceAccountsJsonObject = Get-Content $ServiceAccountsConfigFile | ConvertFrom-Json

$ServiceAccounts = $ServiceAccountsJsonObject.ServiceAccounts

$confirmpreference = 'none'

$myFQDN = [System.Net.Dns]::GetHostByName($env:computerName).HostName

foreach ($ServiceAccountItem in $ServiceAccounts) {

  if ($ServiceAccountItem.modifySPN -eq $true) {
    Write-Host

    ## Modify a service account's Service Principal Names (SPN) information to authenticate correctly.
    Write-Host "Modifying service account $($ServiceAccountItem.Username) SPN information for $($ServiceAccountItem.ServiceName) service ..."
    setspn -D MSSQLSvc/$($myFQDN):1433 $env:computername | Out-Null
    setspn -D MSSQLSvc/$($myFQDN) $env:computername | Out-Null
    setspn -A MSSQLSvc/$($myFQDN):1433 $($ServiceAccountItem.Username) | Out-Null
    setspn -A MSSQLSvc/$($myFQDN) $($ServiceAccountItem.Username) | Out-Null
    setspn -L $($ServiceAccountItem.Username)
    Write-Host "SPN updated"
  }
}


foreach ($ServiceAccountItem in $ServiceAccounts) {

  Write-Host

  ## Set service logon account
  Write-Host "Setting service account $($ServiceAccountItem.ServiceName) on $($env:computername) to $($ServiceAccountItem.Username) ..."
  changeServiceAccount $ServiceAccountItem.ServiceName $env:computername $ServiceAccountItem.Username $ServiceAccountItem.Password
  Write-Host "Changed service account $($ServiceAccountItem.ServiceName) on $($env:computername) to $($ServiceAccountItem.Username) and restarted service"
}

