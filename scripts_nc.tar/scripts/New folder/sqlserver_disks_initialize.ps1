
$DiskLayoutConfigFile = Split-Path $script:MyInvocation.MyCommand.Path
$DiskLayoutConfigFile += "\sqlserver_disks_layout.json"
$DiskLayoutJsonObject = Get-Content $DiskLayoutConfigFile | ConvertFrom-Json

#$DiskLayoutJsonObject.psobject.properties.name

$physicalDisks = Get-PhysicalDisk
foreach ($physicalDisk in $physicalDisks) {
  $lun = "LUN" + ($physicalDisk.DeviceId - 1)
  $deviceId = $physicalDisk.DeviceId

  #if ($physicalDisk.FriendlyName -eq "Msft Virtual Disk" -and $DiskLayoutJsonObject.psobject.Properties.name -contains $lun) {
  if ($physicalDisk.FriendlyName -eq "Msft Virtual Disk" -and $DiskLayoutJsonObject.psobject.Properties.name -match $deviceId) {  
    
    Write-host "Initializing disk $lun - ( Drive:", $DiskLayoutJsonObject.$deviceId.DriveLetter, ", Label:", $DiskLayoutJsonObject.$deviceId.NewFileSystemLabel, "). Please wait..."

    Get-Disk | 
      Where {$_.partitionstyle -eq 'raw' -and $_.UniqueId -eq $physicaldisk.UniqueId} |
      Initialize-Disk -PartitionStyle MBR -PassThru |
      New-Partition -DriveLetter $DiskLayoutJsonObject.$deviceId.DriveLetter -UseMaximumSize |
      Format-Volume -FileSystem $DiskLayoutJsonObject.$deviceId.FileSystem -NewFileSystemLabel $DiskLayoutJsonObject.$deviceId.NewFileSystemLabel -Confirm:$false
  }
}